# Wiz Cloud Detection and Response (CDR) Attack Simulation w/ Custom Schedule - AWS

The following Terraform provides an example of deploying the Wiz Cloud Detection and Response (CDR) Attack Simulation infrastructure into an AWS environment while implementing a custom runner schedule.

```hcl
provider "aws" {}

module "wiz_attack_simulation" {
  source = "<wiz-attack-simulation-aws_directory>"

  attack_simulation_cron = "0 */1 * * *"
}

output "attack_sim_user" {
  value = module.wiz_attack_simulation.attack_sim_user
}
```
