# Wiz Cloud Detection and Response (CDR) Attack Simulation - AWS

The following Terraform provides an example of deploying the Wiz Cloud Detection and Response (CDR) Attack Simulation infrastructure into an AWS environment.

```hcl
provider "aws" {}

module "wiz_attack_simulation" {
  source = "<wiz-attack-simulation-aws_directory>"
}

output "attack_sim_user" {
  value = module.wiz_attack_simulation.attack_sim_user
}
```
