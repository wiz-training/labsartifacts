<!-- BEGIN_TF_DOCS -->
# Wiz Attack Simulation Terraform Module for AWS

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 1.0 |
| aws | >= 5.0 |
| random | >= 3.0 |

## Providers

| Name | Version |
|------|---------|
| aws | >= 5.0 |
| random | >= 3.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| wiz_attack_sim_vpc | terraform-aws-modules/vpc/aws | ~> 5.0 |

## Resources

| Name | Type |
|------|------|
| [aws_iam_access_key.wiz_attack_sim](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_access_key) | resource |
| [aws_iam_user.wiz_attack_sim](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_user) | resource |
| [aws_iam_user_policy.wiz_attack_sim](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_user_policy) | resource |
| [aws_instance.wiz_attack_sim_linux](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/instance) | resource |
| [aws_instance.wiz_attack_sim_runner](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/instance) | resource |
| [aws_instance.wiz_attack_sim_windows](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/instance) | resource |
| [aws_network_interface.wiz_attack_sim_instances](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/network_interface) | resource |
| [aws_network_interface.wiz_attack_sim_runner](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/network_interface) | resource |
| [aws_s3_bucket.wiz_attack_sim](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket) | resource |
| [aws_s3_bucket_public_access_block.wiz_attack_sim](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_public_access_block) | resource |
| [aws_s3_object.wiz_attack_sim](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_object) | resource |
| [aws_security_group.wiz_attack_sim](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [random_id.uniq](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/id) | resource |
| [aws_ami.ubuntu](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ami) | data source |
| [aws_ami.windows](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ami) | data source |
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones) | data source |
| [aws_iam_policy_document.wiz_attack_sim_minimal_permissions](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_partition.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/partition) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| attack_simulation_cron | The cronjob statement for which the attack simulation should execute. | `string` | `"0 */6 * * *"` | no |
| bucket_name | A string representing a user specified name for the S3 bucket. | `string` | `""` | no |
| cluster_name | A string representing a user specified name for the EKS cluster. | `string` | `""` | no |
| instance_ami_linux | A string representing a custom AMI to use for Linux instances. | `string` | `""` | no |
| instance_ami_runner | A string representing a custom AMI to use for the 'runner' instance. | `string` | `""` | no |
| instance_ami_windows | A string representing a custom AMI to use for Windows instances. | `string` | `""` | no |
| instance_count_linux | A number representing the number of Linux EC2 instances to create. | `number` | `3` | no |
| instance_count_windows | A number representing the number of Windows EC2 instances to create. | `number` | `3` | no |
| instance_type | A string representing an instance type for created EC2 instances. | `string` | `"t3.small"` | no |
| instance_volume_size | A string representing the size of the storage volume (in GB) for created EC2 instances. | `string` | `"20"` | no |
| prefix | A string representing the prefix for all created resources. | `string` | `"wiz-attack-simulation"` | no |
| tags | A map/dictionary of Tags to be assigned to created resources. | `map(string)` | `{}` | no |
| user_name | A string representing a user specified name for the IAM user. | `string` | `""` | no |
| user_path | A string representing a user specified path for the IAM user. | `string` | `""` | no |
| vpc_cidr | The CIDR subnet address for the created VPC. | `string` | `"10.0.0.0/16"` | no |
| vpc_name | A string representing a user specified name for the created VPC. | `string` | `""` | no |
| vpc_subnets | The number of subnets to configure for the created VPC. | `string` | `2` | no |

## Outputs

| Name | Description |
|------|-------------|
| attack_sim_user | n/a |
| bucket_arn | n/a |
| bucket_name | n/a |
| vpc_id | n/a |
| vpc_intra_subnets | n/a |
| vpc_private_subnets | n/a |
<!-- END_TF_DOCS -->